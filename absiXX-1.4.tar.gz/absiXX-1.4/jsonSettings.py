import json

jsonSettings= json.dumps(\
[\
{\
    'type': 'numeric',\
	'title':'controls font_size',\
    'section': 'Custom',\
	'desc':'font size, default=32',\
	'key': 'font_size'\
},\
{\
    'type': 'numeric',\
	'title':'book font_size',\
    'section': 'Custom',\
	'desc':'font size, default=32',\
	'key': 'book_font_size'\
}\

])

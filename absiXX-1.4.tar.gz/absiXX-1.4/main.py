#!/usr/bin/env python
# log lever
LOGLEVEL=3  # quieter

from kivy.app import App
from kivy.lang import Builder

from kivy.uix.button import Button

from kivy.uix.image import Image
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.properties import NumericProperty,BoundedNumericProperty, StringProperty, ObjectProperty, ListProperty




from random import randint, randrange
from ABSI_Index import Topics, Pages

def getAbout():
	F=open('about.txt')
	about=F.read()
	F.close()
	return about

BillFold='text/'
def getPage(pn):
	fn= BillFold+str(pn)+'.txt'
	F=open(fn)
	s=F.read()
	F.close()
	return s


class ScrollableLabel(ScrollView):
	text=StringProperty()

class PageTurner(BoxLayout):
	pass

class TopicTurner(BoxLayout):
	# topic=StringProperty()
	pass

class ConPan(BoxLayout):
	pass

class NavPan(BoxLayout):
	pass

class Book(BoxLayout):
	pass

class absiXApp(App):

	pageIndex=NumericProperty(0)
	pageNumber=BoundedNumericProperty(1,min=1,max=332, errorhandler= lambda x: x%332+1)
	pages=ListProperty()
	topic=StringProperty()

	topspin=ObjectProperty()
	pagelab=ObjectProperty()
	scroller=ObjectProperty()
	font_size=NumericProperty(32)
	book_font_size=NumericProperty(32)

	def build(self):
		self.use_kivy_settings=False
		# navpan=NavPan()
		root=Book()
		navpan=root.ids['navpan']
		self.scroller=root.ids['scroller']
		self.topspin=navpan.ids['tturner'].ids['topspin']
		self.pagelab=navpan.ids['pturner'].ids['pageLab']
		print('  **** self.pagelab=%s'%self.pagelab)
		# self.nav=nav
		self.topic=Topics[0]
		self.pages=Pages[self.topic]
		self.pageNumber=self.pages[0]
		self.pagelab.text=str(self.pageNumber)
		self.pageIndex=0
		self.root=root
		self.about=getAbout()
		return root

	def firstPage(self,o=None,v=None):
		self.setPageIndex(0)

	def lastPage(self,o=None,v=None):
		self.setPageIndex( len(self.pages)-1 )

	def nextPage(self,o=None,v=None):
		self.setPageIndex(self.pageIndex+1)

	def backPage(self,o=None,v=None):
		self.setPageIndex(self.pageIndex-1)

	def randPage(self,o=None,v=None):
		self.setPageIndex( randint(0,len(self.pages)-1 ) )

	def setPageIndex(self,x):
		self.pageIndex=x
		print('setting pIndex to %s ==? %s'%(self.pageIndex,x))
		self.setPageNumber(int(self.pages[x]))

	def setPageNumber(self,p):
		self.pageNumber=p
		print('setting page to %s'%p)
		s=getPage(self.pageNumber)
		self.scroller.text=s


	def setTopic(self,top):
		if top in Topics:
			self.topic=top
			self.pages=Pages[top]
			self.setPageIndex(0)
			print('new Topic=%s p1=%s'%(top,self.pages[0]))

	def randTopic(self):
		x=randint(0,len(Topics)-1)
		self.setTopic(Topics[x])

	def on_topic(self, o,v):
		print('=== onTopic() o=%s v=%s'%(o,v))

	def on_pageNumber(self, o,v):
		print('=== onPageNumber() o=%s v=%s'%(o,v))

	def on_pageIndex(self, o,v):
		print('=== onPageIndex() o=%s v=%s'%(o,v))

	# def on_pages(self, o, v):
	# 	print('=== onPages() o=%s v=%s'%(o,v))
	#
	# def on_topspin(self, o, v):
	# 	print('=== onTopspin() o=%s v=%s'%(o,v))

	# Config
	def build_config(self,config):
		config.setdefaults('Custom', {'font_size':32, 'book_font_size':32} )

	def build_settings(self,settings):
		settings.add_json_panel('absiXX', self.config,data=jsonSettings)

	def on_config_change(self,config, section, key, val):
		if key=='font_size':
			self.font_size=int(val)
		if key=='book_font_size':
			self.book_font_size=int(val)

	def doAbout(self, o=None, v=None):
		self.scroller.text=self.about


#### log level performed here LOGLEVEL set on top of page
X=LOGLEVEL

from kivy.config import Config
def setLogLevel(x):
	xx=[ 'trace', 'debug', 'info', 'warning', 'error', 'critical']
	if len(xx)>x>0 :
		Config.set('kivy','log_level',xx[x])
setLogLevel(X)

from kivy.config import ConfigParser
from jsonSettings import jsonSettings




##########   Start App   ##########
absiXApp().run()
